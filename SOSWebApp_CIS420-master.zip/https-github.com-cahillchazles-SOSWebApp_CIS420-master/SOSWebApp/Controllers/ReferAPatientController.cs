﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SOSWebApp.Controllers
{
    public class ReferAPatientController : Controller
    {
        // GET: ReferAPatient
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ReferAPatient()
        {
            return View();
        }
    }
}